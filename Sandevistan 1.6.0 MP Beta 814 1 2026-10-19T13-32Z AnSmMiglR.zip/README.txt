SANDEVISTAN - CASUALTIES: UNKNOWN
Version 1.6.0 - Multiplayer Beta

Wear a neural accelerator on your back, slow the world and move and strike
30% faster. Repeated use causes increasing cyberpsychosis and a blackout.
The Sandevistan HUD is disabled by default.

INSTALLATION

Requires BepInEx 5 x64 and Casualties: Unknown Steam Demo v7.0.1.
Copy the package's BepInEx folder into the folder containing
CasualtiesUnknown.exe. Replace the previous Sandevistan.dll; keep the Assets
folder beside it. The installed mod consists of:

  BepInEx/plugins/Sandevistan/Sandevistan.dll
  BepInEx/plugins/Sandevistan/Assets/EdgeEnterShort.wav
  BepInEx/plugins/Sandevistan/Assets/EdgeExit.wav

CUCoreLib is not required. Multiplayer is optional. Do not install a second
copy of Sandevistan.dll in another plugin folder. Existing settings are kept.

MULTIPLAYER

This beta targets Casualties Together 5.0.2:
https://www.nexusmods.com/scavprototype/mods/67

Install the SAME Sandevistan version, including its Assets, on the host and
EVERY client. A host without Sandevistan cannot run the effect. Activation
waits until all connected players complete the mod handshake; an unsupported
or missing mod prevents activation. This does not automatically install mods
on other players' computers. Single-player remains available without Together.

The host controls activation, charge, cooldown, use counters and medical
consequences. While any device is active, the host's WorldTimeScale setting
applies to the shared world, including enemies, projectiles and liquids.
Other players are slowed unless they also activate their own Sandevistan.
Several devices can run together: each active user receives the same 30%
movement and melee bonus, while every user retains a separate charge and
six-use cycle. Ending one device leaves the slowdown running if another is
still active. The item and colored afterimages are visible to other players.
Screen glitches, darkening, heartbeat and custom activation audio belong to
the affected player's view. Real wounds and collapse statistics originate on
the host and follow Together's medical synchronization.

Together retains its native movement ownership and networking. Network
latency still affects activation, movement corrections and medical updates.
This is an experimental compatibility release. A real co-op playtest is still
recommended before using an important run. This beta has no special PvP
balance rules; Together's normal friendly-fire rules still apply.

CONTROLS AND EQUIPMENT

- Wear Sandevistan through the inventory's normal Wear action, like armor.
  Its icon appears in the lower equipment row and the module is visible on
  the character's back. It uses its own slot, so backpacks remain usable.
- V toggles the equipped device. The same physical key works with English
  and Russian keyboard layouts. Holding or carrying the item is insufficient.
- F8 requests a device if you do not already carry one. In multiplayer the
  host spawns it into your inventory, or places it beside you.
- One device is normally given at the start of a run. It is also utility loot
  and may appear at merchants. Removing it stops your time effect.

TIME AND OVERLOAD

The world normally runs at 20% speed while the device is active. The user's
ground and air movement and melee attacks gain 30% speed. Jump height remains
normal. A full charge lasts 8 real gameplay seconds; the device then has a
6-second cooldown and recharges at 6.25% per second. Activation requires at
least 20% charge. The former three-minute rest requirement is absent.

Each player has a separate cycle of six successful activations:

  1-3: no overload symptoms.
  4: occasional native illness dialogue.
  5: a real, treatable head wound and nosebleed, blood loss and mild glitches.
  6: cyberpsychosis, gradual native speech, denser glitches, slight screen
     darkening and a racing heartbeat. After the effect ends, collapse lasts
     30 real gameplay seconds. The episode lasts at least six seconds even
     if the time effect is switched off early.

Each collapse costs 10 brain integrity points, 5 mood points and raises body
temperature by 3 C, once per cycle. Waking resets the use count; wounds,
lost blood and these health penalties recover through the game's normal
systems. Removing the device does not cancel a pending collapse. Rejected
activation attempts do not count. Death, ragdoll, lost equipment, leaving the
world or disconnecting stops the affected player's acceleration.

CONFIGURATION

Generated file: BepInEx/config/local.casualtiesunknown.sandevistan.cfg
Edit it with the game closed. Main defaults:

  Controls / ActivationKey = V
  Controls / SpawnKey = F8
  Item / GiveAtRunStart = true
  Display / ShowHUD = false
  Balance / WorldTimeScale = 0.2
  Audio / EnableSounds = true
  Audio / SoundVolume = 0.85
  Visuals / EnableAfterimages = true

In multiplayer, the host sets world speed and starter-device policy. Audio,
afterimage presentation and HUD settings remain local. Existing ShowHUD=true
settings are respected; change that value to false if you want no HUD.

SAVES AND REMOVAL

The item uses native inventory and equipment serialization. Temporary use
counters belong to the current player body and restart when it is replaced.
The mod does not save a persistent multiplayer use counter.

Remove Sandevistan items from inventories and containers before uninstalling.
With the game closed, remove BepInEx/plugins/Sandevistan. Other installed mods
are independent. Mods that alter time, physics or medical synchronization
need separate compatibility testing.

CREDITS

Code and pixel icon created for this project. Activation and deactivation
sounds are the user-provided EdgeEnterShort.wav and EdgeExit.wav assets.
Cyberpunk 2077 is not required to run this mod.
